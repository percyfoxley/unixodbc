# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.3.11  | :white_check_mark: |
| < 2.3.x | :x:                |

## Reporting a Vulnerability

Contact nick.gorham@easysoft.com
