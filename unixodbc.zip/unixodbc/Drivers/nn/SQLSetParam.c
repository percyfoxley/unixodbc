/* Moved to SQLBindParameter.c. */
